package com.example.a219_lemonade_stand.CoreComponents.NetworkingSystem;

public class ServerDetails {

    public static final String IP_ADDRESS = "http://192.168.0.50:8080/";

   // public static final String IP_ADDRESS = "localhost:8080/";
}
