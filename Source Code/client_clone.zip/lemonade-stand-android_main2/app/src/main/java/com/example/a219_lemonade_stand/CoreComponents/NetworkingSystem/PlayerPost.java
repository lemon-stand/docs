package com.example.a219_lemonade_stand.CoreComponents.NetworkingSystem;

public class PlayerPost {


    public PlayerPost() {


    }


}
